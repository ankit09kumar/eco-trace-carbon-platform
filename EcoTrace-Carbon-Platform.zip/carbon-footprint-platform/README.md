# 🌿 EcoTrace — Carbon Footprint Awareness Platform

A fully functional, single-page web application for carbon footprint awareness, education, and action.

---

## 🚀 Features

### 1. Hero Section
- Animated rotating 3D globe (Canvas 2D)
- Key climate statistics with animated counters
- Call-to-action buttons

### 2. Dashboard
- Real climate data cards (temperature rise, CO₂ ppm, sea level, renewables)
- Interactive horizontal bar chart showing global emissions by sector
- Data sourced from IPCC, IEA, and Our World in Data

### 3. Personal Carbon Calculator
- 4-step wizard: Transport → Home Energy → Diet → Shopping
- Real-time results with animated donut chart
- Personal carbon score and letter grade
- Breakdown bars for each category
- Based on real emissions factors (India context)

### 4. Action Tips
- 15 evidence-based tips ranked by impact
- Filter by category: Transport, Home, Diet, Shopping
- Impact labels (High / Medium / Low)
- Estimated savings per action

### 5. Pledge Wall
- Users can make personal pledges
- Animated chip display
- Pre-seeded with example pledges

### 6. Community Leaderboard
- Top 10 low-carbon achievers
- Country flags, pledge type, yearly change
- Responsive table layout

---

## 📁 Project Structure

```
carbon-footprint-platform/
├── index.html                    # Main HTML entry point
├── README.md                     # This file
└── src/
    ├── styles/
    │   └── main.css              # Complete design system + styles
    ├── data/
    │   ├── tipsData.js           # 15 evidence-based action tips
    │   └── leaderboardData.js    # Community leaderboard data
    ├── components/
    │   ├── calculator.js         # Multi-step carbon calculator
    │   ├── charts.js             # Donut + bar charts (Canvas/CSS)
    │   ├── tips.js               # Tips grid rendering & filtering
    │   ├── leaderboard.js        # Leaderboard table rendering
    │   ├── pledge.js             # Pledge form & wall
    │   └── globe.js              # Animated 3D globe (Canvas)
    ├── pages/
    │   └── main.js               # Page controller (nav, scroll, etc.)
    └── utils/
        └── helpers.js            # Shared utility functions
```

---

## 🛠️ How to Run

**No build tools required!** This is a pure HTML/CSS/JS project.

1. Open `index.html` in any modern browser
2. Or serve with a simple HTTP server:
   ```bash
   # Python
   python3 -m http.server 8080
   # Node.js (npx)
   npx serve .
   ```
3. Visit `http://localhost:8080`

---

## 🎨 Design

- **Font**: DM Serif Display (headlines) + Space Grotesk (body)
- **Palette**: Forest deep greens (#0d1f13 → #4a9e3f → #c5e629)
- **Signature element**: Rotating 3D globe rendered in Canvas 2D
- **Fully responsive**: Works on mobile, tablet, and desktop

---

## 📊 Data Sources

- Global temperature data: IPCC AR6 (2021)
- CO₂ concentration: NOAA Mauna Loa Observatory
- Emissions by sector: Our World in Data / IEA 2023
- Carbon factors: UK DEFRA, Project Drawdown, EPA

---

## 🔮 Possible Extensions

- [ ] Backend API (Node.js/Python) for persistent user data
- [ ] User authentication & personal dashboards
- [ ] Monthly tracking & progress charts
- [ ] Social sharing of footprint scores
- [ ] Integration with real-time energy grid data
- [ ] Carbon offset marketplace links
- [ ] Gamification (badges, streaks)

---

*Built for climate awareness. Data is real; actions matter.*
