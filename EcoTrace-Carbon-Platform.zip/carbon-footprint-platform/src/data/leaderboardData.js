// src/data/leaderboardData.js
const LEADERBOARD_DATA = [
  { rank: 1, name: "Priya Nair", country: "🇮🇳 India", tons: 1.2, change: "-0.8T", trend: "down", pledge: "Plant-based diet" },
  { rank: 2, name: "Lars Eriksson", country: "🇸🇪 Sweden", tons: 1.5, change: "-1.2T", trend: "down", pledge: "No-fly year" },
  { rank: 3, name: "Amara Diallo", country: "🇸🇳 Senegal", tons: 1.6, change: "-0.6T", trend: "down", pledge: "Solar + cycle" },
  { rank: 4, name: "Chen Wei", country: "🇨🇳 China", tons: 2.1, change: "-0.9T", trend: "down", pledge: "EV commute" },
  { rank: 5, name: "Sofia Mendez", country: "🇧🇷 Brazil", tons: 2.3, change: "-0.4T", trend: "down", pledge: "Zero food waste" },
  { rank: 6, name: "James Okoye", country: "🇳🇬 Nigeria", tons: 2.4, change: "+0.1T", trend: "up", pledge: "Reforestation" },
  { rank: 7, name: "Yuki Tanaka", country: "🇯🇵 Japan", tons: 2.7, change: "-0.3T", trend: "down", pledge: "No single-use" },
  { rank: 8, name: "Emma Wilson", country: "🇬🇧 UK", tons: 3.1, change: "+0.2T", trend: "up", pledge: "Second-hand only" },
  { rank: 9, name: "Marco Rossi", country: "🇮🇹 Italy", tons: 3.4, change: "-0.5T", trend: "down", pledge: "Vegetarian week" },
  { rank: 10, name: "Alex Kim", country: "🇰🇷 Korea", tons: 3.8, change: "-0.2T", trend: "down", pledge: "Public transit" }
];
