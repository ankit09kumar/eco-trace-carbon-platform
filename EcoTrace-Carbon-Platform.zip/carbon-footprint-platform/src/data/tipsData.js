// src/data/tipsData.js
const TIPS_DATA = [
  {
    id: 1, category: "transport", icon: "✈️", impact: "high",
    title: "Skip one long-haul flight",
    desc: "A single return flight from Delhi to London emits ~2.5 tonnes CO₂ — more than many people's annual car use.",
    saving: "Saves 1–4 tonnes CO₂/year"
  },
  {
    id: 2, category: "transport", icon: "🚗", impact: "high",
    title: "Switch to an EV or cycle for commutes",
    desc: "Replacing a petrol car with an EV cuts your personal transport emissions by 60–80%, even on a grid-average electricity mix.",
    saving: "Saves 1.0–2.5 tonnes CO₂/year"
  },
  {
    id: 3, category: "transport", icon: "🚌", impact: "medium",
    title: "Use public transit 3 days/week",
    desc: "A single-occupancy car produces 4x more emissions per km than a bus. Partial shifts make a real difference.",
    saving: "Saves 0.4–0.7 tonnes CO₂/year"
  },
  {
    id: 4, category: "diet", icon: "🥩", impact: "high",
    title: "Cut beef to once a week",
    desc: "Beef produces 60kg CO₂ per kg of protein — 20x more than lentils. Even halving beef intake is impactful.",
    saving: "Saves 0.5–1.8 tonnes CO₂/year"
  },
  {
    id: 5, category: "diet", icon: "🌱", impact: "high",
    title: "Go plant-based 3 days/week",
    desc: "A flexitarian diet (mostly plant-based) cuts food-related emissions by 50%, while keeping nutritional needs met.",
    saving: "Saves 0.5–1.5 tonnes CO₂/year"
  },
  {
    id: 6, category: "diet", icon: "🗑️", impact: "medium",
    title: "Halve your food waste",
    desc: "One-third of all food produced globally is wasted. At home, meal planning and proper storage are the biggest levers.",
    saving: "Saves 0.2–0.5 tonnes CO₂/year"
  },
  {
    id: 7, category: "home", icon: "☀️", impact: "high",
    title: "Install rooftop solar panels",
    desc: "In India, a 3kW system generates ~4,000 kWh/year — covering most household electricity needs with zero operating emissions.",
    saving: "Saves 1.5–3.0 tonnes CO₂/year"
  },
  {
    id: 8, category: "home", icon: "💡", impact: "medium",
    title: "Switch to LED lighting entirely",
    desc: "LEDs use 75% less energy than incandescent bulbs and last 25x longer. Easiest high-ROI upgrade for any home.",
    saving: "Saves 0.1–0.3 tonnes CO₂/year"
  },
  {
    id: 9, category: "home", icon: "🌡️", impact: "medium",
    title: "Adjust thermostat by 2°C",
    desc: "Lowering your heating setpoint by 2°C reduces heating energy use by ~10%. The biggest home-energy behavior change.",
    saving: "Saves 0.2–0.4 tonnes CO₂/year"
  },
  {
    id: 10, category: "home", icon: "🧺", impact: "low",
    title: "Wash clothes in cold water",
    desc: "90% of a washing machine's energy goes to heating water. Cold water gets clothes just as clean and extends fabric life.",
    saving: "Saves 0.1–0.2 tonnes CO₂/year"
  },
  {
    id: 11, category: "shopping", icon: "👕", impact: "medium",
    title: "Buy second-hand clothing",
    desc: "The fashion industry accounts for 10% of global CO₂. A second-hand garment has already paid its carbon debt.",
    saving: "Saves 0.2–0.5 tonnes CO₂/year"
  },
  {
    id: 12, category: "shopping", icon: "📱", impact: "medium",
    title: "Keep your smartphone 3+ years",
    desc: "85% of a smartphone's lifetime carbon comes from manufacturing. Extending use by 2 years nearly halves its impact.",
    saving: "Saves 0.1–0.3 tonnes CO₂/year"
  },
  {
    id: 13, category: "shopping", icon: "♻️", impact: "low",
    title: "Repair before replacing",
    desc: "A repaired appliance avoids 80% of its embodied carbon. Repair cafes and iFixit guides make this easier than ever.",
    saving: "Saves 0.1–0.4 tonnes CO₂/year"
  },
  {
    id: 14, category: "transport", icon: "🚴", impact: "medium",
    title: "Cycle for trips under 5km",
    desc: "Short car trips are the least efficient: cold engines emit more, and the marginal time cost is often just minutes.",
    saving: "Saves 0.2–0.5 tonnes CO₂/year"
  },
  {
    id: 15, category: "home", icon: "💧", impact: "low",
    title: "Install low-flow shower head",
    desc: "Cutting shower water use by 40% reduces water heating — typically 15–20% of home energy use — proportionally.",
    saving: "Saves 0.1–0.2 tonnes CO₂/year"
  }
];
