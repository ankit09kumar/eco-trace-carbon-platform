// src/pages/main.js — Page controller

document.addEventListener('DOMContentLoaded', () => {

  // ---- Navbar scroll effect ----
  const navbar = document.getElementById('navbar');
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
  }, { passive: true });

  // ---- Mobile hamburger ----
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.querySelector('.nav__links');
  hamburger.addEventListener('click', () => {
    const open = navLinks.style.display === 'flex';
    navLinks.style.display = open ? '' : 'flex';
    navLinks.style.flexDirection = 'column';
    navLinks.style.position = 'absolute';
    navLinks.style.top = '100%';
    navLinks.style.left = '0';
    navLinks.style.right = '0';
    navLinks.style.background = 'rgba(13,31,19,0.97)';
    navLinks.style.padding = '1rem 1.5rem';
    navLinks.style.borderBottom = '1px solid rgba(74,158,63,0.2)';
    if (open) {
      navLinks.style.display = '';
    }
  });

  // Close nav on link click
  document.querySelectorAll('.nav__links a').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.style.display = '';
    });
  });

  // ---- Scroll-reveal cards ----
  const revealEls = document.querySelectorAll('.card, .tip-card, .lb-row, .calc__result');
  revealEls.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  });

  const revealObs = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }, 80);
        revealObs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  revealEls.forEach(el => revealObs.observe(el));

  // ---- Stagger tip cards ----
  const tipObs = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const cards = entry.target.querySelectorAll('.tip-card');
        cards.forEach((card, i) => {
          card.style.opacity = '0';
          card.style.transform = 'translateY(24px)';
          card.style.transition = `opacity 0.4s ${i * 0.06}s ease, transform 0.4s ${i * 0.06}s ease`;
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          }, 100 + i * 60);
        });
        tipObs.disconnect();
      }
    });
  }, { threshold: 0.05 });

  const tipsGrid = document.getElementById('tipsGrid');
  if (tipsGrid) tipObs.observe(tipsGrid);

  // ---- Active nav link on scroll ----
  const sections = ['home', 'dashboard', 'calculator', 'tips', 'leaderboard'];
  const navAnchors = document.querySelectorAll('.nav__links a');

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY + 120;
    sections.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      if (scrollY >= el.offsetTop && scrollY < el.offsetTop + el.offsetHeight) {
        navAnchors.forEach(a => a.style.color = '');
        const match = document.querySelector(`.nav__links a[href="#${id}"]`);
        if (match) match.style.color = '#8bc34a';
      }
    });
  }, { passive: true });

  // ---- Initial calc update ----
  updateCalc();
});
