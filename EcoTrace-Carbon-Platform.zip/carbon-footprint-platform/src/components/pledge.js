// src/components/pledge.js

const pledgeLabels = {
  'no-fly': '✈️ flight-free for a year',
  'plant-based': '🌱 plant-based 3×/week',
  'ev': '⚡ cycling/EV commute',
  'solar': '☀️ solar energy',
  'no-buy': '👗 no new clothes 6 months',
  'compost': '♻️ composting'
};

// Seed some pledges
const initialPledges = [
  { name: "Arjun", action: "plant-based" },
  { name: "Sarah", action: "no-fly" },
  { name: "Ravi", action: "ev" },
  { name: "Meera", action: "solar" },
  { name: "Tom", action: "no-buy" }
];

function makePledge() {
  const name = document.getElementById('pledgeName').value.trim();
  const action = document.getElementById('pledgeAction').value;

  if (!name || !action) {
    document.getElementById('pledgeName').style.borderColor = '#e74c3c';
    setTimeout(() => document.getElementById('pledgeName').style.borderColor = '', 1500);
    return;
  }

  addPledgeChip(name, action);
  document.getElementById('pledgeName').value = '';
  document.getElementById('pledgeAction').value = '';
}

function addPledgeChip(name, action) {
  const wall = document.getElementById('pledgeWall');
  const chip = document.createElement('div');
  chip.className = 'pledge-chip';
  chip.textContent = `${name} pledged ${pledgeLabels[action] || action}`;
  wall.prepend(chip);
}

document.addEventListener('DOMContentLoaded', () => {
  initialPledges.forEach(p => addPledgeChip(p.name, p.action));
});
