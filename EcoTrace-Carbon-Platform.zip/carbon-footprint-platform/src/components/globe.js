// src/components/globe.js
// Animated Earth globe using Canvas 2D

(function() {
  const canvas = document.getElementById('globeCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const cx = W / 2, cy = H / 2, r = W / 2 - 10;

  let angle = 0;

  // Simple land masses as lat/lng polygons (simplified)
  const landMasses = [
    // Africa
    [[0,10],[20,37],[30,30],[35,15],[25,-20],[15,-35],[5,-20],[-10,0],[0,10]],
    // Europe
    [[35,45],[25,65],[35,70],[55,65],[60,60],[55,45],[45,42],[35,45]],
    // Asia
    [[55,70],[70,75],[105,70],[120,50],[135,35],[110,20],[90,10],[60,20],[40,40],[55,70]],
    // North America
    [[-120,70],[-60,75],[-55,45],[-75,25],[-90,15],[-120,30],[-140,55],[-165,65],[-120,70]],
    // South America
    [[-80,12],[-65,10],[-55,-5],[-40,-20],[-55,-55],[-68,-55],[-75,-40],[-80,0],[-80,12]],
    // Australia
    [[115,-22],[130,-12],[150,-22],[155,-35],[145,-40],[125,-35],[115,-30],[115,-22]],
  ];

  function latLngToXY(lat, lng, rotAngle) {
    const phi = (90 - lat) * Math.PI / 180;
    const theta = (lng + rotAngle) * Math.PI / 180;
    const x = cx + r * Math.sin(phi) * Math.cos(theta);
    const y = cy + r * Math.cos(phi);
    const z = Math.sin(phi) * Math.sin(theta);
    return { x, y, z };
  }

  function drawGlobe(rot) {
    ctx.clearRect(0, 0, W, H);

    // Ocean base
    const oceanGrad = ctx.createRadialGradient(cx - r*0.2, cy - r*0.2, 0, cx, cy, r);
    oceanGrad.addColorStop(0, '#1a3522');
    oceanGrad.addColorStop(0.6, '#0d1f13');
    oceanGrad.addColorStop(1, '#060d09');
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = oceanGrad;
    ctx.fill();

    // Grid lines (latitude/longitude)
    ctx.strokeStyle = 'rgba(74,158,63,0.12)';
    ctx.lineWidth = 0.5;

    // Latitude lines
    for (let lat = -60; lat <= 60; lat += 30) {
      ctx.beginPath();
      let first = true;
      for (let lng = -180; lng <= 180; lng += 5) {
        const p = latLngToXY(lat, lng, rot);
        if (p.z < 0) { first = true; continue; }
        if (first) { ctx.moveTo(p.x, p.y); first = false; }
        else ctx.lineTo(p.x, p.y);
      }
      ctx.stroke();
    }

    // Longitude lines
    for (let lng = 0; lng < 360; lng += 30) {
      ctx.beginPath();
      let first = true;
      for (let lat = -80; lat <= 80; lat += 5) {
        const p = latLngToXY(lat, lng, rot);
        if (p.z < 0) { first = true; continue; }
        if (first) { ctx.moveTo(p.x, p.y); first = false; }
        else ctx.lineTo(p.x, p.y);
      }
      ctx.stroke();
    }

    // Land masses
    landMasses.forEach(land => {
      ctx.beginPath();
      let started = false;
      land.forEach(([lng, lat]) => {
        const p = latLngToXY(lat, lng, rot);
        if (p.z < -0.1) return;
        if (!started) { ctx.moveTo(p.x, p.y); started = true; }
        else ctx.lineTo(p.x, p.y);
      });
      ctx.closePath();
      ctx.fillStyle = 'rgba(74,158,63,0.55)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(139,195,74,0.4)';
      ctx.lineWidth = 0.8;
      ctx.stroke();
    });

    // Atmosphere glow
    const atmosGrad = ctx.createRadialGradient(cx, cy, r * 0.85, cx, cy, r * 1.02);
    atmosGrad.addColorStop(0, 'rgba(74,158,63,0)');
    atmosGrad.addColorStop(0.5, 'rgba(74,158,63,0.08)');
    atmosGrad.addColorStop(1, 'rgba(139,195,74,0.15)');
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = atmosGrad;
    ctx.fill();

    // Specular highlight
    const specGrad = ctx.createRadialGradient(cx - r*0.35, cy - r*0.35, 0, cx, cy, r);
    specGrad.addColorStop(0, 'rgba(255,255,255,0.12)');
    specGrad.addColorStop(0.4, 'rgba(255,255,255,0.03)');
    specGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = specGrad;
    ctx.fill();

    // Edge clip
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.clip();
    ctx.restore();
  }

  function animate() {
    angle = (angle + 0.2) % 360;
    drawGlobe(angle);
    requestAnimationFrame(animate);
  }

  animate();
})();
