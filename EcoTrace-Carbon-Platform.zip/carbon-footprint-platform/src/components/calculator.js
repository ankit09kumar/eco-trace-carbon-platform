// src/components/calculator.js

const calcState = {
  currentStep: 1,
  totalSteps: 4,
  values: {
    carKm: 100,
    flights: 0,
    transit: 0,
    electricBill: 2000,
    heat: 1,
    diet: 3.3,
    waste: 1,
    clothingItems: 20,
    electronics: 0.3
  }
};

function selectOpt(btn, key) {
  const group = btn.closest('.option-btns');
  group.querySelectorAll('.opt').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  calcState.values[key] = parseFloat(btn.dataset.val);
  updateCalc();
}

function updateCalc() {
  // Read range inputs
  const carKmEl = document.getElementById('carKm');
  const electricEl = document.getElementById('electricBill');
  const clothingEl = document.getElementById('clothingItems');

  if (carKmEl) {
    calcState.values.carKm = parseInt(carKmEl.value);
    document.getElementById('carKmVal').textContent = `${calcState.values.carKm} km`;
  }
  if (electricEl) {
    calcState.values.electricBill = parseInt(electricEl.value);
    document.getElementById('electricBillVal').textContent = `₹${calcState.values.electricBill.toLocaleString()}`;
  }
  if (clothingEl) {
    calcState.values.clothingItems = parseInt(clothingEl.value);
    document.getElementById('clothingItemsVal').textContent = `${calcState.values.clothingItems} items`;
  }

  computeAndDisplay();
}

function computeAndDisplay() {
  const v = calcState.values;

  // Transport (tonnes/year)
  const carEmissions = (v.carKm * 52 * 0.17) / 1000; // 170g CO2/km
  const flightEmissions = v.flights * 0.5;
  const transitDiscount = v.transit * 0.05;
  const transport = Math.max(0, carEmissions + flightEmissions - transitDiscount);

  // Home (tonnes/year)
  const electricEmissions = (v.electricBill * 12 * 0.7) / 1000; // 0.7 kg CO2 per ₹1 electricity (approx India grid)
  const home = electricEmissions * v.heat;

  // Diet (tonnes/year)
  const diet = v.diet * v.waste;

  // Shopping (tonnes/year)
  const clothingEmissions = (v.clothingItems * 6.5) / 1000; // ~6.5 kg per garment
  const shopping = clothingEmissions + v.electronics;

  const total = transport + home + diet + shopping;
  const maxVal = Math.max(total, 0.1);

  // Update display
  document.getElementById('totalTons').textContent = total.toFixed(1);
  document.getElementById('transportTons').textContent = transport.toFixed(1) + 'T';
  document.getElementById('homeTons').textContent = home.toFixed(1) + 'T';
  document.getElementById('dietTons').textContent = diet.toFixed(1) + 'T';
  document.getElementById('shoppingTons').textContent = shopping.toFixed(1) + 'T';

  const maxCat = Math.max(transport, home, diet, shopping, 0.01);
  document.getElementById('transportBar').style.width = (transport / maxCat * 100) + '%';
  document.getElementById('homeBar').style.width = (home / maxCat * 100) + '%';
  document.getElementById('dietBar').style.width = (diet / maxCat * 100) + '%';
  document.getElementById('shoppingBar').style.width = (shopping / maxCat * 100) + '%';

  // Grade
  let grade, gradeClass, gradeText;
  if (total < 2) {
    grade = 'A'; gradeClass = 'grade-a';
    gradeText = 'Excellent! Below the 2050 Paris target.';
  } else if (total < 4) {
    grade = 'B'; gradeClass = 'grade-b';
    gradeText = 'Good — below global average. Keep going.';
  } else if (total < 7) {
    grade = 'C'; gradeClass = 'grade-c';
    gradeText = 'Around global average. Room to improve.';
  } else {
    grade = 'D'; gradeClass = 'grade-d';
    gradeText = 'Above average. Your actions here can matter.';
  }

  const gradeEl = document.getElementById('gradeLabel');
  gradeEl.textContent = grade;
  gradeEl.className = `grade ${gradeClass}`;
  document.getElementById('gradeText').textContent = gradeText;

  // Donut chart
  drawDonutChart(transport, home, diet, shopping, total);
}

function changeStep(dir) {
  const steps = document.querySelectorAll('.calc__step');
  const dots = document.querySelectorAll('.dot');

  steps[calcState.currentStep - 1].classList.remove('active');
  dots[calcState.currentStep - 1].classList.remove('active');

  calcState.currentStep = Math.max(1, Math.min(calcState.totalSteps, calcState.currentStep + dir));

  steps[calcState.currentStep - 1].classList.add('active');
  dots[calcState.currentStep - 1].classList.add('active');

  document.getElementById('prevBtn').disabled = calcState.currentStep === 1;
  const nextBtn = document.getElementById('nextBtn');
  nextBtn.textContent = calcState.currentStep === calcState.totalSteps ? 'Done ✓' : 'Next →';
  if (calcState.currentStep === calcState.totalSteps) {
    nextBtn.onclick = () => scrollToSection('tips');
  } else {
    nextBtn.onclick = () => changeStep(1);
  }

  updateCalc();
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  updateCalc();
});
