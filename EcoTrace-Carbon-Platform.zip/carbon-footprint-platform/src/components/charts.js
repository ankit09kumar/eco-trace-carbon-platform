// src/components/charts.js

// ---- Donut chart (canvas) ----
function drawDonutChart(transport, home, diet, shopping, total) {
  const canvas = document.getElementById('resultDonut');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const cx = canvas.width / 2, cy = canvas.height / 2;
  const radius = 80, lineWidth = 22;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (total <= 0) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.lineWidth = lineWidth;
    ctx.stroke();
    return;
  }

  const segments = [
    { value: transport, color: '#4a9e3f' },
    { value: home,      color: '#8bc34a' },
    { value: diet,      color: '#c5e629' },
    { value: shopping,  color: '#2d5a27' }
  ];

  let startAngle = -Math.PI / 2;
  const gap = 0.03;

  segments.forEach(seg => {
    if (seg.value <= 0) return;
    const slice = (seg.value / total) * (Math.PI * 2 - segments.length * gap);
    ctx.beginPath();
    ctx.arc(cx, cy, radius, startAngle + gap/2, startAngle + slice + gap/2);
    ctx.strokeStyle = seg.color;
    ctx.lineWidth = lineWidth;
    ctx.lineCap = 'round';
    ctx.stroke();
    startAngle += slice + gap;
  });
}

// ---- Sector bar chart ----
const SECTOR_DATA = [
  { label: "Energy (Electricity & Heat)", pct: 34, color: "#ff6b5b" },
  { label: "Transport", pct: 16, color: "#ffc048" },
  { label: "Agriculture", pct: 11, color: "#4ddb84" },
  { label: "Industry (manufacturing)", pct: 24, color: "#74b9ff" },
  { label: "Buildings", pct: 6, color: "#c5e629" },
  { label: "Other (waste, LULUCF)", pct: 9, color: "#bd93f9" }
];

function renderSectorChart() {
  const container = document.getElementById('sectorChart');
  if (!container) return;

  container.innerHTML = SECTOR_DATA.map(d => `
    <div class="bar-row">
      <span class="bar-row__label">${d.label}</span>
      <div class="bar-row__track">
        <div class="bar-row__fill" style="width:0%; background:${d.color}" data-target="${d.pct}"></div>
      </div>
      <span class="bar-row__pct">${d.pct}%</span>
    </div>
  `).join('');

  // Animate in when visible
  setTimeout(() => {
    container.querySelectorAll('.bar-row__fill').forEach(bar => {
      bar.style.transition = 'width 1.4s cubic-bezier(0.4,0,0.2,1)';
      bar.style.width = bar.dataset.target + '%';
    });
  }, 200);
}

// ---- Animated counter hero stats ----
function animateHeroStats() {
  document.querySelectorAll('.stat__num').forEach(el => {
    const target = parseFloat(el.dataset.target);
    animateValue(el, 0, target, 1800);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  renderSectorChart();

  // Trigger hero stats when in view
  const statsEl = document.querySelector('.hero__stats');
  if (statsEl) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) { animateHeroStats(); obs.disconnect(); }
      });
    }, { threshold: 0.5 });
    obs.observe(statsEl);
  }
});
