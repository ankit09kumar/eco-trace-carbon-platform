// src/components/leaderboard.js

function renderLeaderboard() {
  const container = document.getElementById('leaderboardTable');
  if (!container) return;

  container.innerHTML = `
    <div class="lb-header">
      <span>Rank</span>
      <span>Name</span>
      <span>Country</span>
      <span>Tonnes CO₂/yr</span>
      <span>Change</span>
    </div>
    ${LEADERBOARD_DATA.map(row => `
      <div class="lb-row">
        <span class="lb-rank ${row.rank <= 3 ? 'top-3' : ''}">${row.rank <= 3 ? ['🥇','🥈','🥉'][row.rank-1] : row.rank}</span>
        <div>
          <div class="lb-name">${row.name}</div>
          <div style="font-size:0.75rem;color:rgba(240,244,232,0.4);margin-top:2px">${row.pledge}</div>
        </div>
        <span class="lb-country">${row.country}</span>
        <span class="lb-tons">${row.tons}T</span>
        <span class="lb-change change-${row.trend}">${row.change} this year</span>
      </div>
    `).join('')}
  `;
}

document.addEventListener('DOMContentLoaded', renderLeaderboard);
