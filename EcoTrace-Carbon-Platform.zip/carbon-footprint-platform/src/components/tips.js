// src/components/tips.js

function renderTips() {
  const container = document.getElementById('tipsGrid');
  if (!container) return;

  container.innerHTML = TIPS_DATA.map(tip => `
    <div class="tip-card" data-category="${tip.category}" data-id="${tip.id}">
      <div class="tip-card__header">
        <span class="tip-card__icon">${tip.icon}</span>
        <span class="tip-card__impact impact-${tip.impact}">
          ${tip.impact.charAt(0).toUpperCase() + tip.impact.slice(1)} Impact
        </span>
      </div>
      <h4>${tip.title}</h4>
      <p>${tip.desc}</p>
      <p class="tip-card__saving">💚 ${tip.saving}</p>
    </div>
  `).join('');
}

function filterTips(btn) {
  document.querySelectorAll('.filter').forEach(f => f.classList.remove('active'));
  btn.classList.add('active');

  const filter = btn.dataset.filter;
  document.querySelectorAll('.tip-card').forEach(card => {
    if (filter === 'all' || card.dataset.category === filter) {
      card.classList.remove('hidden');
    } else {
      card.classList.add('hidden');
    }
  });
}

document.addEventListener('DOMContentLoaded', renderTips);
